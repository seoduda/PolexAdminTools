<?php
/**
 * Created by PhpStorm.
 * User: Duda
 * Date: 27/03/2016
 * Time: 19:52
 */

class polex_admin_produtos_assinatura {
    public $fieldNames = array ('ap_id','ass_id', 'cli_id', 'prd_id', 'exp_id', 'pais_id', 'prd_volume', 'prd_edicao', 'prd_nome', 'end_nome_destinatario', 'end_endereco', 'end_numero', 'end_complemento', 'end_endereco_linha2', 'end_bairro', 'end_cidade', 'end_estado', 'end_pais', 'end_cep', 'ap_ordem', 'ap_data_envio', 'ap_status', 'ap_id', 'id');
    public $data;
}