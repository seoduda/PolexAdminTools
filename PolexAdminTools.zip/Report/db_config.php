<?php
/**
 * Created by PhpStorm.
 * User: Duda
 * Date: 04/04/2016
 * Time: 02:24
 */

class db_config {
    public $db_hostname = 'mysql01.site1376498500.hospedagemdesites.ws';
    public $db_database = 'site1376498500';
    public $db_username = 'site1376498500';
    public $db_password = 'c7HmgP0LXt';
}