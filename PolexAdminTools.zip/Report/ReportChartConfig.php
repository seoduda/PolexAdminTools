<?php
/**
 * Created by PhpStorm.
 * User: Duda
 * Date: 19/03/2016
 * Time: 13:07
 */

class ReportChartConfig {
    public $title,$width,$height;


} 