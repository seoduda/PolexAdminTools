<?php
/**
 * Created by PhpStorm.
 * User: Duda
 * Date: 04/04/2016
 * Time: 02:00
 */

class db_config {
    public $db_hostname = 'localhost';
    public $db_database = 'publications';
    public $db_username = 'username';
    public $db_password = 'password';
}
?>